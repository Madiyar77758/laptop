﻿<#
    Единая точка входа.

    Порядок намеренно такой: СНАЧАЛА открывается панель, и только потом
    начинается диагностика. Человек, только что разрешивший запуск, должен
    сразу увидеть продукт, а не чёрное окно с бегущими строками. Пока
    железо опрашивается, панель показывает ход проверки и обновляется
    сама, как только результат готов.

    Права берёт LaptopCheck.bat, поэтому сканеру передаётся -NoElevate:
    иначе Windows спросила бы разрешение второй раз.

    Весь текст для человека живёт здесь, а не в .bat — cmd.exe читает
    батники в кодировке OEM и портит кириллицу.
#>

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

function Line { param([string]$T, [string]$C = 'Gray') Write-Host "  $T" -ForegroundColor $C }

$scan   = Join-Path $here 'scan.ps1'
$server = Join-Path $here 'live.ps1'
foreach ($f in @($scan, $server, (Join-Path $here 'panel.html'))) {
    if (-not (Test-Path $f)) {
        Line "Не хватает файла: $(Split-Path $f -Leaf)" 'Red'
        Line "Распакуйте архив целиком, не по одному файлу." 'DarkGray'
        Read-Host "`n  Enter — выход"; exit 1
    }
}

Write-Host ""
Line "LaptopCheck" 'White'
Line ("─" * 44) 'DarkGray'
Write-Host ""
if (-not $isAdmin) {
    Line "Без прав администратора часть проверок недоступна:" 'DarkYellow'
    Line "износ диска, температуры и журнал ошибок." 'DarkYellow'
    Write-Host ""
}

# Прошлый результат убираем: иначе панель мгновенно покажет данные от
# предыдущего запуска и человек решит, что проверка уже закончилась.
$resultPath = Join-Path $here 'scan_result.json'
Remove-Item $resultPath -Force -ErrorAction SilentlyContinue

# --- панель вперёд ---------------------------------------------------
Line "Открываю панель..." 'White'
$srv = Start-Process -FilePath (Get-Process -Id $PID).Path `
    -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass',
                  '-File', "`"$server`"" `
    -WindowStyle Hidden -PassThru

Start-Sleep -Milliseconds 1400

Write-Host ""
Line "Панель открылась в браузере. Дальше она всё покажет сама." 'DarkGreen'
Line "Это окно закрывать нельзя — на нём держится панель." 'DarkYellow'
Write-Host ""
Line "Читаю железо, около полуминуты..." 'DarkGray'

# --- диагностика -----------------------------------------------------
& powershell -NoProfile -ExecutionPolicy Bypass -File $scan -NoElevate -Quiet

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Line "Диагностика завершилась с ошибкой." 'Red'
} else {
    Write-Host ""
    Line "Готово — заключение в браузере." 'DarkGreen'
}

Write-Host ""
Line "Закончите — нажмите Enter, панель закроется." 'DarkGray'
Read-Host | Out-Null

if ($srv -and -not $srv.HasExited) {
    Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
}
