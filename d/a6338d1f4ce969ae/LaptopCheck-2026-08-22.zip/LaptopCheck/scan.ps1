﻿<#
    LaptopCheck — глубокая диагностика б/у ноутбука перед покупкой.

    Чем это отличается от AIDA64 и прочих инвентаризаторов:

    1. ИСТОРИЯ ОТКАЗОВ. Журнал событий Windows помнит ошибки диска,
       аппаратные сбои WHEA, синие экраны и аварийные выключения за
       месяцы до продажи. Продавец переустановит систему — но если
       он этого не сделал, история видна насквозь.

    2. ПЕРЕКРЁСТНЫЕ ПРОВЕРКИ. Отдельно взятый факт мало что значит.
       Значит их сопоставление: матрица 2023 года в корпусе 2019-го —
       это замена экрана. Диск с наработкой 200 часов в пятилетнем
       ноутбуке — диск меняли. Об этом стоит спросить продавца.

    3. ВЕРДИКТ, А НЕ ДАМП. Человеку на встрече нужен ответ, а не
       четыреста строк характеристик.

    Запуск:
        powershell -ExecutionPolicy Bypass -File scan.ps1

    Часть данных (SMART, износ SSD, часы наработки) доступна только
    администратору. Без прав скрипт не падает — помечает "не проверено".
#>

param(
    [string]$JsonOut = "$PSScriptRoot\scan_result.json",
    [switch]$SkipStress,
    [switch]$NoElevate,
    [switch]$Quiet
)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'

$IsAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Без прав администратора закрыто самое ценное: SMART диска, часы
# наработки, полный журнал событий. Просим повышение сразу, иначе
# половина проверок молча превратится в "не проверено".
if (-not $IsAdmin -and -not $NoElevate) {
    Write-Host ""
    Write-Host "  Для полной диагностики нужны права администратора." -ForegroundColor Yellow
    Write-Host "  Сейчас Windows спросит разрешение — согласитесь." -ForegroundColor DarkGray
    Write-Host ""
    $argList = @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass',
        '-NoExit', '-File', "`"$PSCommandPath`"",
        '-JsonOut', "`"$JsonOut`""
    )
    if ($SkipStress) { $argList += '-SkipStress' }
    if ($Quiet)      { $argList += '-Quiet' }
    try {
        Start-Process -FilePath (Get-Process -Id $PID).Path `
                      -Verb RunAs -ArgumentList $argList -ErrorAction Stop
        exit 0
    } catch {
        Write-Host "  Повышение прав отклонено — продолжаю в урезанном режиме." -ForegroundColor DarkYellow
        Write-Host ""
    }
}

$R = [ordered]@{
    schema_version = 2
    scanned_at     = (Get-Date).ToString('o')
    admin_rights   = $IsAdmin
    system         = @{}
    battery        = @{}
    storage        = @()
    smart          = @()
    volumes        = @()
    cpu            = @{}
    memory         = @{}
    memory_modules = @()
    display        = @{}
    panels         = @()
    gpu            = @()
    network        = @()
    devices        = @{}
    security       = @{}
    history        = @{}
    inventory      = @{}
    crosschecks    = @()
    findings       = @()
}

function Get-PluralRu {
    param([double]$N, [string[]]$Forms)   # ('год','года','лет')
    if ($N -ne [math]::Floor($N)) { return $Forms[1] }
    $n = [int]$N; $m100 = $n % 100
    if ($m100 -ge 11 -and $m100 -le 14) { return $Forms[2] }
    switch ($n % 10) {
        1 { return $Forms[0] }
        {$_ -in 2,3,4} { return $Forms[1] }
        default { return $Forms[2] }
    }
}

function Add-Finding {
    <#
        Уровни различаются намеренно:
          ok      — проверено, всё хорошо
          warn    — проверено, есть вопрос
          bad     — проверено, есть проблема
          note    — проверено, просто к сведению
          unknown — ПРОВЕРИТЬ НЕ УДАЛОСЬ

        Путать note и unknown нельзя: в подвале заключения перечисляются
        именно unknown как пробелы проверки. Если пометить справочную
        строку словом unknown, отчёт соврёт, что чего-то не смог.
    #>
    param(
        [ValidateSet('ok','warn','bad','note','unknown')] [string]$Level,
        [string]$Area, [string]$Text, [int]$Penalty = 0
    )
    $R.findings += [ordered]@{ level=$Level; area=$Area; text=$Text; penalty=$Penalty }
}

function Say { param([string]$T) if (-not $Quiet) { Write-Host $T -ForegroundColor DarkGray } }

# Атрибуты SMART, которые действительно говорят о здоровье диска.
# Остальные полторы сотни — телеметрия производителя, в вердикте шума
# от них больше, чем пользы.
$SMART_NAMES = @{
      5 = 'Переназначенные секторы'
      9 = 'Часы наработки'
     12 = 'Циклов включения'
    184 = 'Ошибки сквозной проверки'
    187 = 'Неисправимые ошибки'
    188 = 'Таймауты команд'
    190 = 'Температура (воздушный поток)'
    194 = 'Температура'
    196 = 'Событий переназначения'
    197 = 'Секторы-кандидаты на переназначение'
    198 = 'Неисправимые при чтении'
    199 = 'Ошибки интерфейса (CRC)'
    231 = 'Остаток ресурса SSD'
    233 = 'Остаток ресурса флеш-памяти'
    241 = 'Записано хостом'
    242 = 'Прочитано хостом'
}
# Атрибуты, ненулевое сырое значение которых — прямой признак умирающего диска
$SMART_CRITICAL = @(5, 184, 187, 188, 196, 197, 198)

function Get-SmartData {
    <#
        Читает таблицу SMART через WMI и раскладывает её на атрибуты.
        Формат: 512 байт, с отступа 2 идут по 12 байт на атрибут:
        [0] номер, [1-2] флаги, [3] текущее, [4] худшее, [5-10] сырое.
        Работает для дисков на ATA/SATA; NVMe так не опрашивается —
        для них остаются счётчики надёжности Windows.
    #>
    $out = @{}
    $tables = Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_ATAPISmartData
    $status = Get-CimInstance -Namespace root\wmi -ClassName MSStorageDriver_FailurePredictStatus

    foreach ($t in $tables) {
        $bytes = $t.VendorSpecific
        if (-not $bytes -or $bytes.Count -lt 362) { continue }
        $attrs = @()
        for ($i = 2; $i + 11 -lt $bytes.Count -and $i -lt 362; $i += 12) {
            $id = [int]$bytes[$i]
            if ($id -eq 0) { continue }
            $raw = [int64]0
            for ($k = 5; $k -ge 0; $k--) { $raw = $raw * 256 + [int64]$bytes[$i + 5 + $k] }
            $attrs += [ordered]@{
                id       = $id
                name     = $(if ($SMART_NAMES.ContainsKey($id)) { $SMART_NAMES[$id] } else { "Атрибут $id" })
                value    = [int]$bytes[$i + 3]
                worst    = [int]$bytes[$i + 4]
                raw      = $raw
                known    = $SMART_NAMES.ContainsKey($id)
                critical = ($SMART_CRITICAL -contains $id)
            }
        }
        $predict = $null
        $st = $status | Where-Object { $_.InstanceName -eq $t.InstanceName } | Select-Object -First 1
        if ($st) { $predict = [bool]$st.PredictFailure }
        $out[$t.InstanceName] = @{ attributes = $attrs; predict_failure = $predict }
    }
    return $out
}

Say "  проверяю систему..."

# ============================================================ СИСТЕМА

$cs    = Get-CimInstance Win32_ComputerSystem
$bios  = Get-CimInstance Win32_BIOS
$os    = Get-CimInstance Win32_OperatingSystem
$board = Get-CimInstance Win32_BaseBoard
$encl  = Get-CimInstance Win32_SystemEnclosure

$biosDate = $null
if ($bios.ReleaseDate) { $biosDate = [datetime]$bios.ReleaseDate }
$ageYears = $null
if ($biosDate) { $ageYears = [math]::Round(((Get-Date) - $biosDate).TotalDays / 365.25, 1) }

# Тип корпуса: 8,9,10,14 = переносной/ноутбук/сабноутбук
$chassisCodes = @($encl.ChassisTypes)
$isLaptop = $false
foreach ($c in $chassisCodes) { if ($c -in 8,9,10,11,12,14,18,21,31,32) { $isLaptop = $true } }

$R.system = [ordered]@{
    manufacturer  = $cs.Manufacturer
    model         = $cs.Model
    sku           = $cs.SystemSKUNumber
    family        = $cs.SystemFamily
    serial        = $bios.SerialNumber
    board         = "$($board.Manufacturer) $($board.Product)"
    board_serial  = $board.SerialNumber
    bios_version  = $bios.SMBIOSBIOSVersion
    bios_vendor   = $bios.Manufacturer
    bios_date     = $(if ($biosDate) { $biosDate.ToString('yyyy-MM-dd') } else { $null })
    approx_age_yr = $ageYears
    is_laptop     = $isLaptop
    os            = $os.Caption
    os_build      = $os.BuildNumber
    os_install    = $(if ($os.InstallDate) { ([datetime]$os.InstallDate).ToString('yyyy-MM-dd') } else { $null })
    uptime_hours  = $(if ($os.LastBootUpTime) { [math]::Round(((Get-Date) - [datetime]$os.LastBootUpTime).TotalHours,1) } else { $null })
}

if ($ageYears -ne $null) {
    $yw = Get-PluralRu $ageYears @('год','года','лет')
    if ($ageYears -ge 8) {
        Add-Finding bad 'Возраст' "Примерно $ageYears $yw — комплектующие на исходе ресурса" 15
    } elseif ($ageYears -ge 5) {
        Add-Finding warn 'Возраст' "Примерно $ageYears $yw" 7
    } else {
        Add-Finding ok 'Возраст' "Примерно $ageYears $yw" 0
    }
}

if (-not $isLaptop -and $chassisCodes.Count -gt 0) {
    Add-Finding warn 'Корпус' 'Устройство опознано не как ноутбук — проверьте, что сканируете то самое' 0
}

$daysSinceInstall = $null
if ($os.InstallDate) {
    $daysSinceInstall = ((Get-Date) - [datetime]$os.InstallDate).TotalDays
    if ($daysSinceInstall -lt 14) {
        Add-Finding warn 'Windows' `
            ("Система переустановлена {0} дн. назад — история отказов стёрта" -f [math]::Round($daysSinceInstall)) 0
    }
}

# ============================================================ БАТАРЕЯ

Say "  читаю батарею..."

$batXml = Join-Path $env:TEMP "lc_bat_$PID.xml"
$null = powercfg /batteryreport /output $batXml /xml 2>$null
$hasBattery = $false

if (Test-Path $batXml) {
    try {
        [xml]$bx = Get-Content $batXml -Encoding UTF8
        $pack = $bx.BatteryReport.Batteries.Battery
        if ($pack) {
            $hasBattery = $true
            if ($pack -is [array]) { $pack = $pack[0] }
            $design = [double]$pack.DesignCapacity
            $full   = [double]$pack.FullChargeCapacity
            $cycles = $pack.CycleCount
            $wear = $null
            if ($design -gt 0 -and $full -gt 0) { $wear = [math]::Round((1 - $full/$design)*100, 1) }

            # История ёмкости: показывает, продолжает ли батарея сыпаться
            $hist = @()
            foreach ($e in $bx.BatteryReport.History.HistoryEntry) {
                if ($e.EnergyEstimation.FullChargeCapacity) {
                    $hist += [pscustomobject]@{
                        Period = $e.StartDate
                        Full   = [double]$e.EnergyEstimation.FullChargeCapacity
                    }
                }
            }
            $trend = $null
            if ($hist.Count -ge 4 -and $design -gt 0) {
                $oldest = $hist[0].Full; $newest = $hist[-1].Full
                if ($oldest -gt 0) { $trend = [math]::Round((1 - $newest/$oldest)*100, 1) }
            }

            $R.battery = [ordered]@{
                present         = $true
                manufacturer    = $pack.Manufacturer
                serial          = $pack.SerialNumber
                chemistry       = $pack.Chemistry
                design_mwh      = $design
                full_charge_mwh = $full
                wear_percent    = $wear
                cycle_count     = $(if ($cycles) { [int]$cycles } else { $null })
                decline_percent = $trend
                history_points  = $hist.Count
            }

            if ($wear -ne $null) {
                if ($wear -ge 40)      { Add-Finding bad  'Батарея' "Износ $wear% — держит меньше двух третей, скоро под замену" 20 }
                elseif ($wear -ge 25)  { Add-Finding warn 'Батарея' "Износ $wear% — заметно просела" 10 }
                elseif ($wear -ge 15)  { Add-Finding warn 'Батарея' "Износ $wear% — в пределах нормы для б/у" 4 }
                else                   { Add-Finding ok   'Батарея' "Износ $wear% — отличное состояние" 0 }
            }
            if ($cycles -and [int]$cycles -gt 800) {
                Add-Finding warn 'Батарея' "Циклов заряда: $cycles — ресурс выработан" 5
            }
            if ($trend -ne $null -and $trend -ge 8) {
                Add-Finding warn 'Батарея' "Ёмкость продолжает падать: минус $trend% за период наблюдений" 5
            }
        }
    } catch { }
    Remove-Item $batXml -Force -ErrorAction SilentlyContinue
}

if (-not $hasBattery) {
    $R.battery = @{ present = $false }
    if ($isLaptop) { Add-Finding bad 'Батарея' 'Батарея не определяется — её нет или она мертва' 25 }
}

# ============================================================ НАКОПИТЕЛИ

Say "  опрашиваю диски..."

$disks = Get-PhysicalDisk
if (-not $disks) {
    $disks = Get-CimInstance Win32_DiskDrive | ForEach-Object {
        [pscustomobject]@{ FriendlyName=$_.Model; MediaType='Unspecified'
                           Size=$_.Size; HealthStatus=$_.Status; BusType='Unknown' }
    }
}

$maxDiskHours = 0
foreach ($d in $disks) {
    if ("$($d.BusType)" -in @('USB','SD','MMC')) { continue }
    if ($d.Size -and $d.Size -lt 24GB) { continue }

    $entry = [ordered]@{
        model=$d.FriendlyName; media_type="$($d.MediaType)"; bus="$($d.BusType)"
        size_gb=[math]::Round($d.Size/1GB); health="$($d.HealthStatus)"
        firmware=$d.FirmwareVersion; serial=$d.SerialNumber
        wear_percent=$null; power_on_hours=$null; temperature_c=$null
        read_errors=$null; write_errors=$null; start_stop=$null
    }

    $rc = $d | Get-StorageReliabilityCounter
    if ($rc) {
        if ($rc.Wear -ne $null)             { $entry.wear_percent   = [int]$rc.Wear }
        if ($rc.PowerOnHours -ne $null)     { $entry.power_on_hours = [int]$rc.PowerOnHours }
        if ($rc.Temperature -ne $null)      { $entry.temperature_c  = [int]$rc.Temperature }
        if ($rc.ReadErrorsTotal -ne $null)  { $entry.read_errors    = [int]$rc.ReadErrorsTotal }
        if ($rc.WriteErrorsTotal -ne $null) { $entry.write_errors   = [int]$rc.WriteErrorsTotal }
        if ($rc.StartStopCycleCount -ne $null) { $entry.start_stop  = [int]$rc.StartStopCycleCount }
    }
    if ($entry.power_on_hours -gt $maxDiskHours) { $maxDiskHours = $entry.power_on_hours }

    $R.storage += $entry

    $name = $entry.model
    $healthy = ($entry.health -eq 'Healthy' -or $entry.health -eq 'OK')

    if (-not $healthy -and $entry.health) {
        Add-Finding bad 'Диск' "$name ($($entry.size_gb) ГБ) — состояние '$($entry.health)'" 25
    } elseif ($entry.media_type -eq 'HDD') {
        Add-Finding warn 'Диск' "$name, $($entry.size_gb) ГБ — обычный HDD, а не SSD: система будет тормозить" 12
    } else {
        $kind = $(if ($entry.media_type -and $entry.media_type -ne 'Unspecified') { $entry.media_type } else { 'диск' })
        Add-Finding ok 'Диск' "$name — $kind, $($entry.size_gb) ГБ, состояние в норме" 0
    }

    if ($entry.wear_percent -ne $null) {
        if ($entry.wear_percent -ge 50)     { Add-Finding bad  'Диск' "$name — износ ячеек $($entry.wear_percent)%" 20 }
        elseif ($entry.wear_percent -ge 20) { Add-Finding warn 'Диск' "$name — износ ячеек $($entry.wear_percent)%" 8 }
        else                                { Add-Finding ok   'Диск' "$name — износ ячеек $($entry.wear_percent)%, ресурс в порядке" 0 }
    }
    if ($entry.power_on_hours -ne $null) {
        $yrs = [math]::Round($entry.power_on_hours/8760.0, 1)
        if ($entry.power_on_hours -gt 20000) {
            Add-Finding warn 'Диск' "$name — наработка $($entry.power_on_hours) ч (~$yrs г. непрерывной работы)" 8
        } else {
            Add-Finding ok 'Диск' "$name — наработка $($entry.power_on_hours) ч" 0
        }
    }
    $errs = 0
    if ($entry.read_errors)  { $errs += $entry.read_errors }
    if ($entry.write_errors) { $errs += $entry.write_errors }
    if ($errs -gt 0) { Add-Finding bad 'Диск' "$name — ошибок чтения/записи: $errs" 15 }
}

if (-not $IsAdmin) {
    Add-Finding unknown 'Диск' 'Износ SSD, часы наработки и SMART не прочитаны — нужен запуск от администратора' 0
} else {
    Say "  разбираю SMART..."
    $smart = Get-SmartData
    $R.smart = @()
    foreach ($inst in $smart.Keys) {
        $tbl = $smart[$inst]
        $R.smart += [ordered]@{
            instance        = $inst
            predict_failure = $tbl.predict_failure
            attributes      = @($tbl.attributes | Where-Object { $_.known })
        }

        if ($tbl.predict_failure -eq $true) {
            Add-Finding bad 'SMART' 'Диск сам сообщает о скором отказе — брать нельзя' 40
        }

        foreach ($a in $tbl.attributes) {
            if (-not $a.critical -or $a.raw -le 0) { continue }
            switch ($a.id) {
                5   { Add-Finding bad  'SMART' "Переназначенных секторов: $($a.raw) — поверхность сыпется" 25 }
                197 { Add-Finding bad  'SMART' "Секторов-кандидатов на переназначение: $($a.raw) — диск на грани" 25 }
                198 { Add-Finding bad  'SMART' "Неисправимых при чтении: $($a.raw) — данные уже теряются" 30 }
                187 { Add-Finding bad  'SMART' "Неисправимых ошибок: $($a.raw)" 20 }
                196 { Add-Finding warn 'SMART' "Событий переназначения: $($a.raw)" 10 }
                184 { Add-Finding bad  'SMART' "Ошибок сквозной проверки: $($a.raw)" 20 }
                188 { Add-Finding warn 'SMART' "Таймаутов команд: $($a.raw) — возможны проблемы со шлейфом" 8 }
            }
        }
        # 199 не в критических: единичные ошибки интерфейса часто лечатся
        # переподключением шлейфа и о смерти диска не говорят.
        $crc = $tbl.attributes | Where-Object { $_.id -eq 199 -and $_.raw -gt 10 }
        if ($crc) {
            Add-Finding warn 'SMART' "Ошибок интерфейса: $($crc.raw) — плохой контакт или шлейф" 8
        }
        $life = $tbl.attributes | Where-Object { $_.id -in @(231, 233) } | Select-Object -First 1
        if ($life -and $life.value -le 100) {
            if ($life.value -lt 20) {
                Add-Finding bad 'SMART' "Остаток ресурса памяти: $($life.value)% — диск почти выработан" 22
            } elseif ($life.value -lt 50) {
                Add-Finding warn 'SMART' "Остаток ресурса памяти: $($life.value)%" 10
            } else {
                Add-Finding ok 'SMART' "Остаток ресурса памяти: $($life.value)%" 0
            }
        }
        $bad = @($tbl.attributes | Where-Object { $_.critical -and $_.raw -gt 0 })
        if ($bad.Count -eq 0 -and $tbl.predict_failure -ne $true) {
            Add-Finding ok 'SMART' 'Критические атрибуты чисты — переназначенных секторов нет' 0
        }
    }
    if ($R.smart.Count -eq 0) {
        # Для NVMe это не пробел: ATA-таблицы у них нет в принципе, а износ,
        # температуру и наработку отдают счётчики надёжности Windows —
        # они уже опрошены выше. Поэтому note, а не unknown.
        $haveCounters = @($R.storage | Where-Object {
            $_.wear_percent -ne $null -or $_.power_on_hours -ne $null
        }).Count -gt 0
        if ($haveCounters) {
            Add-Finding note 'SMART' 'Диск NVMe — ATA-таблицы SMART у него нет, состояние взято из счётчиков Windows' 0
        } else {
            Add-Finding unknown 'SMART' 'Таблица SMART недоступна' 0
        }
    }
}

# Свободное место — на это смотрят редко, а забитый под пробку диск
# означает, что систему ждёт тормоза сразу после покупки.
foreach ($v in (Get-Volume | Where-Object { $_.DriveLetter -and $_.FileSystemType -ne 'Unknown' })) {
    $sizeGb = [math]::Round($v.Size/1GB)
    if ($sizeGb -le 0) { continue }
    $freePct = [math]::Round($v.SizeRemaining/$v.Size*100)
    $R.volumes += [ordered]@{
        letter="$($v.DriveLetter)"; fs="$($v.FileSystemType)"
        size_gb=$sizeGb; free_gb=[math]::Round($v.SizeRemaining/1GB)
        free_percent=$freePct; health="$($v.HealthStatus)"
    }
    if ($v.DriveLetter -eq 'C' -and $freePct -lt 10) {
        Add-Finding warn 'Диск' "Системный раздел забит: свободно $freePct%" 5
    }
}

# ============================================================ ПРОЦЕССОР

Say "  проверяю процессор..."

$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$R.cpu = [ordered]@{
    name=$cpu.Name; cores=$cpu.NumberOfCores; threads=$cpu.NumberOfLogicalProcessors
    max_clock_mhz=$cpu.MaxClockSpeed; current_clock_mhz=$cpu.CurrentClockSpeed
    l2_kb=$cpu.L2CacheSize; l3_kb=$cpu.L3CacheSize
    socket=$cpu.SocketDesignation; virtualization=$cpu.VirtualizationFirmwareEnabled
    temperature_c=$null; load_clock_mhz=$null; throttle_percent=$null
}

$tz = Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature
if ($tz) {
    $tc = ($tz | Measure-Object -Property CurrentTemperature -Maximum).Maximum
    if ($tc -gt 0) {
        $celsius = [math]::Round(($tc/10) - 273.15, 1)
        $R.cpu.temperature_c = $celsius
        if ($celsius -ge 85)     { Add-Finding bad  'Температура' "$celsius°C в простое — охлаждение забито" 15 }
        elseif ($celsius -ge 70) { Add-Finding warn 'Температура' "$celsius°C в простое — повышенная, нужна чистка" 8 }
        else                     { Add-Finding ok   'Температура' "$celsius°C — норма" 0 }
    }
} elseif (-not $IsAdmin) {
    Add-Finding unknown 'Температура' 'Датчик требует прав администратора' 0
} else {
    # Даже под администратором зона ACPI есть не у всех: многие ноутбуки
    # её просто не публикуют, и достать температуру можно только своим
    # драйвером ядра — тем самым путём, которым идёт AIDA64.
    Add-Finding unknown 'Температура' 'Ноутбук не публикует термозону ACPI — без драйвера ядра не прочитать' 0
}

# Короткая нагрузка: если под нагрузкой частота проваливается сильно ниже
# паспортной, ноутбук уходит в троттлинг — забито охлаждение или деградировала
# термопаста. Это то, чего не увидеть в простое.
if (-not $SkipStress) {
    Say "  нагружаю процессор на 8 секунд..."
    $jobs = @()
    $n = [math]::Max(1, [int]$cpu.NumberOfLogicalProcessors)
    for ($i = 0; $i -lt $n; $i++) {
        $jobs += Start-Job -ScriptBlock {
            $end = (Get-Date).AddSeconds(8); $x = 0.0
            while ((Get-Date) -lt $end) { for ($k=0; $k -lt 90000; $k++) { $x += [math]::Sqrt($k) } }
        }
    }
    Start-Sleep -Seconds 6
    $samples = @()
    for ($s = 0; $s -lt 3; $s++) {
        $c = Get-CimInstance Win32_Processor | Select-Object -First 1
        if ($c.CurrentClockSpeed) { $samples += $c.CurrentClockSpeed }
        Start-Sleep -Milliseconds 400
    }
    $jobs | Wait-Job -Timeout 15 | Out-Null
    $jobs | Remove-Job -Force

    if ($samples.Count -gt 0 -and $cpu.MaxClockSpeed -gt 0) {
        $loadClock = [int](($samples | Measure-Object -Average).Average)
        $R.cpu.load_clock_mhz = $loadClock
        $ratio = $loadClock / $cpu.MaxClockSpeed
        $R.cpu.throttle_percent = [math]::Round((1 - $ratio) * 100)
        # MaxClockSpeed — это буст ОДНОГО ядра. Под нагрузкой на все ядра
        # частота законно ниже: у здорового Ryzen/Core это 60-75% от буста.
        # Поэтому тревога только при явном провале, иначесканер будет
        # обвинять в троттлинге исправные машины.
        if ($ratio -lt 0.40) {
            Add-Finding bad 'Троттлинг' `
                ("Под нагрузкой всего {0} МГц из {1} — процессор резко режет частоту, охлаждение не справляется" -f $loadClock, $cpu.MaxClockSpeed) 15
        } elseif ($ratio -lt 0.55) {
            Add-Finding warn 'Троттлинг' `
                ("Под нагрузкой {0} МГц из {1} — частота просаживается сильнее обычного" -f $loadClock, $cpu.MaxClockSpeed) 7
        } else {
            Add-Finding ok 'Троттлинг' `
                ("Под нагрузкой держит {0} МГц из {1} — норма" -f $loadClock, $cpu.MaxClockSpeed) 0
        }
    }
}

# ============================================================ ПАМЯТЬ

$ram   = Get-CimInstance Win32_PhysicalMemory
$array = Get-CimInstance Win32_PhysicalMemoryArray | Select-Object -First 1
$totalGb = [math]::Round((($ram | Measure-Object -Property Capacity -Sum).Sum)/1GB)

$typeMap = @{ 20='DDR'; 21='DDR2'; 24='DDR3'; 26='DDR4'; 34='DDR5'; 0='неизвестно' }
foreach ($m in $ram) {
    $R.memory_modules += [ordered]@{
        slot=$m.DeviceLocator; capacity_gb=[math]::Round($m.Capacity/1GB)
        speed_mhz=$m.Speed; manufacturer=$m.Manufacturer
        part=$m.PartNumber; serial=$m.SerialNumber
        type=$(if ($typeMap.ContainsKey([int]$m.SMBIOSMemoryType)) { $typeMap[[int]$m.SMBIOSMemoryType] } else { "код $($m.SMBIOSMemoryType)" })
    }
}

$R.memory = [ordered]@{
    total_gb=$totalGb; modules=@($ram).Count
    slots_total=$(if ($array) { $array.MemoryDevices } else { $null })
    speed_mhz=($ram | Select-Object -First 1).Speed
    upgradable=$(if ($array) { @($ram).Count -lt $array.MemoryDevices } else { $null })
}

if ($totalGb -le 4)     { Add-Finding bad  'Память' "$totalGb ГБ — мало даже для браузера" 15 }
elseif ($totalGb -le 8) { Add-Finding warn 'Память' "$totalGb ГБ — впритык для сегодняшних задач" 6 }
else                    { Add-Finding ok   'Память' "$totalGb ГБ" 0 }

if ($R.memory.upgradable -eq $true) {
    Add-Finding ok 'Память' "Свободен слот — память можно нарастить" 0
} elseif ($array -and @($ram).Count -ge $array.MemoryDevices -and $totalGb -le 8) {
    Add-Finding warn 'Память' "Все слоты заняты — нарастить память не выйдет без замены модулей" 3
}

# ============================================================ ЭКРАН

Say "  читаю матрицу..."

# EDID матрицы: год выпуска панели — главный признак замены экрана
$panels = Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorID
$panelYear = $null
foreach ($p in $panels) {
    $mfg = -join ($p.ManufacturerName | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })
    $name = -join ($p.UserFriendlyName | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })
    $ser  = -join ($p.SerialNumberID   | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })
    $R.panels += [ordered]@{
        manufacturer=$mfg; name=$name; serial=$ser
        year=$p.YearOfManufacture; week=$p.WeekOfManufacture
    }
    if ($p.YearOfManufacture -and ($panelYear -eq $null -or $p.YearOfManufacture -lt $panelYear)) {
        $panelYear = [int]$p.YearOfManufacture
    }
}

$vc = Get-CimInstance Win32_VideoController
foreach ($v in $vc) {
    $R.gpu += [ordered]@{
        name=$v.Name; driver=$v.DriverVersion
        driver_date=$(if ($v.DriverDate) { ([datetime]$v.DriverDate).ToString('yyyy-MM-dd') } else { $null })
        ram_mb=$(if ($v.AdapterRAM -gt 0) { [math]::Round($v.AdapterRAM/1MB) } else { $null })
    }
}
$primary = $vc | Where-Object { $_.CurrentHorizontalResolution } | Select-Object -First 1
$R.display = [ordered]@{
    width=$primary.CurrentHorizontalResolution
    height=$primary.CurrentVerticalResolution
    hz=$primary.CurrentRefreshRate
}
if ($primary.CurrentHorizontalResolution -and $primary.CurrentHorizontalResolution -lt 1920) {
    Add-Finding warn 'Экран' ("Разрешение {0}x{1} — ниже Full HD" -f $primary.CurrentHorizontalResolution, $primary.CurrentVerticalResolution) 6
} elseif ($primary.CurrentHorizontalResolution) {
    $hz = $primary.CurrentRefreshRate
    Add-Finding ok 'Экран' ("{0}x{1}, {2} Гц" -f $primary.CurrentHorizontalResolution, $primary.CurrentVerticalResolution, $hz) 0
}

# ============================================================ СЕТЬ И УСТРОЙСТВА

# Перечисление PnP — самый тяжёлый запрос во всём сканере (несколько
# тысяч записей). Делаем его ОДИН раз и дальше фильтруем в памяти:
# четыре отдельных вызова растягивали проверку почти на минуту.
Say "  перечисляю устройства..."
$pnp = Get-CimInstance Win32_PnPEntity

$netAdapters = Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -eq $true }
foreach ($n in $netAdapters) {
    $R.network += [ordered]@{ name=$n.Name; mac=$n.MACAddress; type=$n.AdapterType }
}
$hasWifi = @($netAdapters | Where-Object { $_.Name -match 'Wi-?Fi|Wireless|WLAN|802\.11' }).Count -gt 0
$hasBt   = @($pnp | Where-Object { $_.Name -match 'Bluetooth' }).Count -gt 0
$cams    = @($pnp | Where-Object { $_.PNPClass -eq 'Camera' -or $_.Name -match 'Webcam|Camera|Камера' })
$audio   = @(Get-CimInstance Win32_SoundDevice | Where-Object { $_.Status -eq 'OK' })

$R.devices = [ordered]@{
    wifi=$hasWifi; bluetooth=$hasBt
    camera=($cams.Count -gt 0); camera_name=$(if ($cams.Count) { $cams[0].Name } else { $null })
    audio_devices=$audio.Count
}

if (-not $hasWifi -and $isLaptop) { Add-Finding bad 'Сеть' 'Wi-Fi адаптер не найден — модуль мёртв или отключён' 15 }
if ($isLaptop -and $cams.Count -eq 0) { Add-Finding warn 'Камера' 'Камера не определяется' 5 }
if ($audio.Count -eq 0) { Add-Finding warn 'Звук' 'Звуковые устройства не определяются' 8 }

# Устройства с ошибкой в диспетчере — прямое указание на неисправность.
# Виртуальные адаптеры (VirtualBox, VMware, Hyper-V) сюда лезть не должны:
# они принадлежат software, а не железу, и их состояние к ноутбуку
# отношения не имеет.
$virtualRe = 'VirtualBox|VMware|Hyper-V|WAN Miniport|Microsoft (Kernel|ISATAP|Teredo|6to4)|Loopback|TAP-|OpenVPN|Wintun|Docker|Bluetooth Device \(RFCOMM'
$badDevs = $pnp |
    Where-Object { $_.ConfigManagerErrorCode -ne 0 -and $_.ConfigManagerErrorCode -ne $null } |
    Where-Object { $_.Name -notmatch $virtualRe }
if ($badDevs) {
    $names = ($badDevs | Select-Object -First 3 | ForEach-Object { $_.Name }) -join '; '
    Add-Finding bad 'Устройства' "В диспетчере устройств ошибки ($(@($badDevs).Count) шт.): $names" 12
} else {
    Add-Finding ok 'Устройства' 'В диспетчере устройств ошибок нет' 0
}

# ============================================================ БЕЗОПАСНОСТЬ

$tpm = Get-CimInstance -Namespace root/cimv2/security/microsofttpm -ClassName Win32_Tpm
$secureBoot = $null
try { $secureBoot = Confirm-SecureBootUEFI } catch { }

# Фильтр обязан быть В САМОМ запросе. Перечислять все лицензии и отсеивать
# уже в PowerShell — 21 секунда на ровном месте; с фильтром на стороне
# провайдера те же данные приходят за полсекунды.
# ApplicationID ниже — это идентификатор именно Windows, не Office.
$lic = Get-CimInstance -Query @"
SELECT LicenseStatus, ProductKeyChannel, Name FROM SoftwareLicensingProduct
WHERE ApplicationID='55c92734-d682-4d71-983e-d6ec3f16059f'
AND PartialProductKey IS NOT NULL
"@ | Select-Object -First 1
$licStatus = switch ([int]$lic.LicenseStatus) {
    1 { 'активирована' } 2 { 'льготный период' } 3 { 'льготный период (OEM)' }
    4 { 'льготный период (не подлинная)' } 5 { 'не активирована' }
    6 { 'дополнительный льготный период' } default { 'неизвестно' }
}

$R.security = [ordered]@{
    tpm_present=($tpm -ne $null); tpm_version=$tpm.SpecVersion
    secure_boot=$secureBoot
    windows_license=$licStatus
    license_channel=$lic.ProductKeyChannel
}

if ($lic -and [int]$lic.LicenseStatus -ne 1) {
    Add-Finding warn 'Windows' "Лицензия: $licStatus — систему придётся активировать самому" 4
} elseif ($lic) {
    Add-Finding ok 'Windows' "Лицензия активирована ($($lic.ProductKeyChannel))" 0
}

# ============================================================ ИНВЕНТАРИЗАЦИЯ

Say "  переписываю железо..."

function Pnp-List {
    param([string[]]$Classes, [string]$NameLike, [int]$Limit = 40)
    $sel = $pnp | Where-Object {
        ($Classes -and $_.PNPClass -in $Classes) -or
        ($NameLike -and $_.Name -match $NameLike)
    }
    @($sel | Select-Object -First $Limit | ForEach-Object {
        [ordered]@{
            name   = $_.Name
            id     = $_.DeviceID
            status = $_.Status
            error  = $_.ConfigManagerErrorCode
        }
    })
}

$proc = Get-CimInstance Win32_Processor | Select-Object -First 1
$cache = Get-CimInstance Win32_CacheMemory

$R.inventory = [ordered]@{
    chipset = @(Pnp-List -NameLike 'Chipset|Host Bridge|PCI Express Root|SMBus' -Limit 12)
    cpu_detail = [ordered]@{
        id            = $proc.ProcessorId
        family        = $proc.Family
        stepping      = $proc.Stepping
        revision      = $proc.Revision
        architecture  = $proc.Architecture
        address_width = $proc.AddressWidth
        l1_kb         = (@($cache | Where-Object { $_.Level -eq 3 }) | Measure-Object -Property MaxCacheSize -Sum).Sum
        l2_kb         = $proc.L2CacheSize
        l3_kb         = $proc.L3CacheSize
        virtualization_fw = $proc.VirtualizationFirmwareEnabled
        vt_enabled    = $proc.VMMonitorModeExtensions
    }
    storage_controllers = @(Pnp-List -Classes @('SCSIAdapter','HDC') -Limit 12)
    usb_controllers     = @(Pnp-List -Classes @('USB') -NameLike 'USB.*(Controller|Host)' -Limit 20)
    audio_devices       = @(Pnp-List -Classes @('MEDIA','AudioEndpoint') -Limit 16)
    network_devices     = @(Pnp-List -Classes @('Net') -Limit 16)
    input_devices       = @(Pnp-List -Classes @('Keyboard','Mouse','HIDClass') -Limit 24)
    bluetooth           = @(Pnp-List -Classes @('Bluetooth') -Limit 12)
    card_readers        = @(Pnp-List -NameLike 'Card Reader|SD Host|MMC' -Limit 8)
    firmware            = [ordered]@{
        bios_vendor  = $bios.Manufacturer
        bios_version = $bios.SMBIOSBIOSVersion
        smbios       = "$($bios.SMBIOSMajorVersion).$($bios.SMBIOSMinorVersion)"
        embedded_ctl = "$($bios.EmbeddedControllerMajorVersion).$($bios.EmbeddedControllerMinorVersion)"
    }
}

# Wi-Fi: поколение стандарта заметно влияет на цену, а в объявлениях о нём
# не пишут никогда.
$wifiNic = $netAdapters | Where-Object { $_.Name -match 'Wi-?Fi|Wireless|WLAN|802\.11' } | Select-Object -First 1
if ($wifiNic) {
    # Порядок важен: 6E должен проверяться раньше 6, иначе строка
    # "Wi-Fi 6E" совпадёт с шаблоном "Wi-Fi 6" и поколение занизится.
    $std = switch -Regex ($wifiNic.Name) {
        'BE\d{3}|Wi-Fi 7'        { 'Wi-Fi 7 (802.11be)'; break }
        'Wi-Fi 6E|AXE\d{3}'      { 'Wi-Fi 6E (802.11ax, диапазон 6 ГГц)'; break }
        'AX\d{3}|Wi-Fi 6'        { 'Wi-Fi 6 (802.11ax)'; break }
        'AC\s?\d{4}|Wireless-AC' { 'Wi-Fi 5 (802.11ac)'; break }
        'N\s?\d{3}'              { 'Wi-Fi 4 (802.11n)'; break }
        default                  { $null }
    }
    $R.inventory.wifi_standard = $std
    if ($std) { Add-Finding ok 'Сеть' "$($wifiNic.Name) — $std" 0 }
}

$R.inventory.pnp_total = @($pnp).Count

# ============================================================ ИСТОРИЯ ОТКАЗОВ

Say "  поднимаю журнал событий..."

function Count-Events {
    param([string]$LogName, [int[]]$Ids, [string]$Provider, [int]$Days = 180)
    $filter = @{ LogName = $LogName; StartTime = (Get-Date).AddDays(-$Days) }
    if ($Ids)     { $filter['ID'] = $Ids }
    if ($Provider){ $filter['ProviderName'] = $Provider }
    $ev = Get-WinEvent -FilterHashtable $filter -MaxEvents 500 -ErrorAction SilentlyContinue
    return @($ev).Count
}

# Событие 153 — "операция ввода-вывода повторена". Это НЕ отказ диска:
# чаще всего его сыплет пустой картридер или флешка, и таких записей
# набегают сотни на совершенно здоровой машине. Считаем отдельно и
# в вердикт по диску не пускаем — иначе продукт будет пугать людей зря.
$diskErrors   = Count-Events -LogName 'System' -Ids @(7,11,51,52) -Provider 'disk'
$diskRetries  = Count-Events -LogName 'System' -Ids @(153) -Provider 'disk'
$ntfsErrors   = Count-Events -LogName 'System' -Ids @(55,137,140) -Provider 'Ntfs'
$wheaErrors   = Count-Events -LogName 'System' -Ids @(17,18,19,20,47) -Provider 'Microsoft-Windows-WHEA-Logger'
$bugchecks    = Count-Events -LogName 'System' -Ids @(1001) -Provider 'Microsoft-Windows-WER-SystemErrorReporting'
$dirtyShutdown= Count-Events -LogName 'System' -Ids @(41) -Provider 'Microsoft-Windows-Kernel-Power'
$thermalEv    = Count-Events -LogName 'System' -Ids @(86,87,88) -Provider 'Microsoft-Windows-Kernel-Processor-Power'

$dumps = @(Get-ChildItem "$env:SystemRoot\Minidump\*.dmp" -ErrorAction SilentlyContinue)

$R.history = [ordered]@{
    window_days=180
    disk_errors=$diskErrors; disk_retries=$diskRetries
    ntfs_errors=$ntfsErrors; whea_errors=$wheaErrors
    bluescreens=$bugchecks; dirty_shutdowns=$dirtyShutdown; thermal_events=$thermalEv
    minidumps=$dumps.Count
    last_minidump=$(if ($dumps.Count) { ($dumps | Sort-Object LastWriteTime -Descending)[0].LastWriteTime.ToString('yyyy-MM-dd') } else { $null })
    readable=$IsAdmin
}

if (-not $IsAdmin) {
    Add-Finding unknown 'История' 'Журнал событий читается не полностью — нужен запуск от администратора' 0
}

if ($diskErrors -gt 0 -or $ntfsErrors -gt 0) {
    $tot = $diskErrors + $ntfsErrors
    Add-Finding bad 'История' "Ошибки диска в журнале за полгода: $tot — диск сыпется" 22
} elseif ($IsAdmin) {
    Add-Finding ok 'История' 'Ошибок диска в журнале за полгода нет' 0
}
# Повторы ввода-вывода: сами по себе не приговор, но если их много и
# картридер пуст — стоит взглянуть на шлейф или разъём накопителя.
if ($diskRetries -ge 50 -and $diskErrors -eq 0) {
    Add-Finding note 'История' `
        "Повторов ввода-вывода: $diskRetries. Обычно это пустой картридер или флешка, а не диск" 0
}
if ($wheaErrors -gt 0) {
    Add-Finding bad 'История' "Аппаратные сбои WHEA: $wheaErrors — отказывает железо, а не Windows" 25
}
if ($bugchecks -gt 0 -or $dumps.Count -gt 0) {
    $n = [math]::Max($bugchecks, $dumps.Count)
    $when = $(if ($R.history.last_minidump) { ", последний $($R.history.last_minidump)" } else { "" })
    Add-Finding warn 'История' "Синих экранов: $n$when" 10
}
# Событие Kernel-Power 41 пишется при любом выключении "не по-людски",
# включая зажатую кнопку питания. У живого ноутбука за полгода их
# набирается с десяток, поэтому тревожимся только на явном перекосе.
if ($dirtyShutdown -gt 15) {
    Add-Finding warn 'История' "Аварийных выключений: $dirtyShutdown — стоит проверить питание и перегрев" 6
}
if ($thermalEv -gt 0) {
    Add-Finding warn 'История' "Событий перегрева в журнале: $thermalEv" 10
}

# ============================================================ ПЕРЕКРЁСТНЫЕ ПРОВЕРКИ

Say "  сверяю узлы между собой..."

function Add-Cross { param([string]$Text, [string]$Level='warn', [int]$Penalty=0)
    $R.crosschecks += @{ text=$Text; level=$Level }
    Add-Finding $Level 'Сверка' $Text $Penalty
}

$biosYear = $(if ($biosDate) { $biosDate.Year } else { $null })

# 1. Матрица новее корпуса -> экран меняли
if ($panelYear -and $biosYear -and ($panelYear - $biosYear) -ge 2) {
    Add-Cross "Матрица $panelYear года в корпусе $biosYear года — экран меняли. Спросите почему." 'warn' 5
}
# 2. Диск почти без наработки в старом ноутбуке -> диск меняли
if ($maxDiskHours -gt 0 -and $ageYears -and $ageYears -ge 3 -and $maxDiskHours -lt 1500) {
    Add-Cross "Наработка диска всего $maxDiskHours ч при возрасте $ageYears г. — диск новый или менялся." 'ok' 0
}
# 3. Диск с наработкой, сильно превышающей возраст корпуса
if ($maxDiskHours -gt 0 -and $ageYears -and $maxDiskHours / 8760.0 -gt ($ageYears + 1)) {
    Add-Cross "Наработка диска $maxDiskHours ч больше возраста корпуса — диск переставили с другой машины." 'warn' 5
}
# 4. Батарея с нулевым износом на старом ноутбуке -> меняли (это хорошо)
if ($hasBattery -and $R.battery.wear_percent -ne $null -and
    $R.battery.wear_percent -lt 5 -and $ageYears -and $ageYears -ge 4) {
    Add-Cross "Батарея как новая при возрасте $ageYears г. — её меняли. Это в плюс." 'ok' 0
}
# 5. Windows поставлена раньше выпуска BIOS -> дата сбита
if ($os.InstallDate -and $biosDate -and ([datetime]$os.InstallDate) -lt $biosDate.AddDays(-30)) {
    Add-Cross "Windows установлена раньше выпуска BIOS — часы или дата в системе сбиты." 'warn' 0
}
# Проверку "серийник корпуса != серийник платы" здесь сознательно НЕТ.
# У большинства производителей ноутбуков это расхождение штатное, и
# обвинение в замене платы било бы по исправным машинам. Обвинять
# продавца можно только тем, в чём уверен.

if ($R.crosschecks.Count -eq 0) {
    Add-Finding ok 'Сверка' 'Узлы согласуются между собой — следов замены не видно' 0
}

# ============================================================ ИТОГ

$score = 100
foreach ($f in $R.findings) { $score -= $f.penalty }
if ($score -lt 0) { $score = 0 }
$R.score = $score

if     ($score -ge 85) { $R.verdict='Хорошее состояние'; $emoji='🟢' }
elseif ($score -ge 65) { $R.verdict='Есть вопросы';      $emoji='🟡' }
elseif ($score -ge 45) { $R.verdict='Заметный износ';    $emoji='🟠' }
else                   { $R.verdict='Брать рискованно';  $emoji='🔴' }

$R | ConvertTo-Json -Depth 6 | Out-File -FilePath $JsonOut -Encoding utf8

if (-not $Quiet) {
    $icon = @{ ok='✅'; warn='⚠️ '; bad='❌'; note='ℹ️ '; unknown='❔' }
    Write-Host ""
    Write-Host "  $($R.system.manufacturer) $($R.system.model)" -ForegroundColor White
    Write-Host "  $($R.cpu.name)" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  $emoji  $score/100 — $($R.verdict)" -ForegroundColor Cyan
    Write-Host ""
    foreach ($f in $R.findings) {
        $color = switch ($f.level) {
            'ok' {'Green'} 'warn' {'Yellow'} 'bad' {'Red'}
            'note' {'Cyan'} default {'DarkGray'}
        }
        Write-Host ("  {0} {1,-12} {2}" -f $icon[$f.level], $f.area, $f.text) -ForegroundColor $color
    }
    Write-Host ""
    if (-not $IsAdmin) {
        Write-Host "  Часть проверок пропущена. Для полного отчёта запустите от администратора." -ForegroundColor DarkYellow
        Write-Host ""
    }
    Write-Host "  Отчёт: $JsonOut" -ForegroundColor DarkGray
    Write-Host ""
}
