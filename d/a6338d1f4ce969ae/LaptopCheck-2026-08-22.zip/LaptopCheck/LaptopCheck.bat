@echo off
rem ---------------------------------------------------------------
rem  Only ASCII here on purpose.
rem  cmd.exe reads .bat files in the OEM codepage, so Cyrillic text
rem  inside a batch file turns into garbage on some machines and the
rem  script stops parsing. All human-facing text lives in run.ps1,
rem  where UTF-8 works properly. This file only asks for rights and
rem  hands over.
rem ---------------------------------------------------------------

rem Path travels through an environment variable, never inlined into the
rem PowerShell command string. Two reasons, both real:
rem   - a folder whose name is written in Cyrillic gets mangled by the
rem     OEM codepage when it travels the command line as text;
rem   - a path with spaces or an apostrophe breaks PowerShell quoting.
rem The process environment is Unicode and needs no quoting, so it is
rem the only reliable channel here.
set "LC_SELF=%~f0"
set "LC_DIR=%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath $env:LC_SELF -Verb RunAs" 2>nul
    if errorlevel 1 goto :noadmin
    exit /b
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%LC_DIR%run.ps1"
exit /b

:noadmin
rem Elevation refused or blocked by policy. Still run: a partial check is
rem better than a closed window with no explanation. run.ps1 says plainly
rem what is missing, and the panel repeats it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%LC_DIR%run.ps1"
