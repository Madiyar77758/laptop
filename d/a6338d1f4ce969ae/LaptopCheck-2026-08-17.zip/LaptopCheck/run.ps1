﻿<#
    Единая точка входа: диагностика -> заключение в браузере.

    Запускается через LaptopCheck.bat, который сначала берёт права
    администратора. Здесь права уже есть, поэтому сканеру передаётся
    -NoElevate: иначе Windows спросит разрешение второй раз.

    Весь текст для человека живёт здесь, а не в .bat — cmd.exe читает
    батники в кодировке OEM и портит кириллицу.
#>

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

function Line { param([string]$T, [string]$C = 'Gray') Write-Host "  $T" -ForegroundColor $C }

Write-Host ""
Line "LaptopCheck — проверка б/у ноутбука" 'White'
Line ("=" * 46) 'DarkGray'
Write-Host ""

if ($isAdmin) {
    Line "Права администратора получены — доступны все проверки." 'DarkGreen'
} else {
    Line "Без прав администратора: SMART диска, часы наработки и" 'DarkYellow'
    Line "журнал событий прочитать не удастся." 'DarkYellow'
}
Write-Host ""

# ---------------------------------------------------------------- шаг 1
Line "[1/3] Читаю железо. Это займёт около полуминуты." 'White'
Write-Host ""

$scan = Join-Path $here 'scan.ps1'
if (-not (Test-Path $scan)) {
    Line "Не нашёл scan.ps1 рядом с этим файлом." 'Red'
    Read-Host "`n  Enter — выход"; exit 1
}
& powershell -NoProfile -ExecutionPolicy Bypass -File $scan -NoElevate
if ($LASTEXITCODE -ne 0) {
    Line "Диагностика завершилась с ошибкой." 'Red'
    Read-Host "`n  Enter — выход"; exit 1
}

# ---------------------------------------------------------------- шаг 2
Write-Host ""
Line "[2/3] Ручная проверка — то, что видно только глазом." 'White'
Line "Битые пиксели, залипающие клавиши, хрип в динамиках." 'DarkGray'
Write-Host ""
$doChecks = Read-Host "  Пройти сейчас? (д/н, по умолчанию н)"
if ($doChecks -match '^[дdyу]') {
    $checksPage = Join-Path $here 'checks.html'
    if (Test-Path $checksPage) {
        Start-Process $checksPage
        Write-Host ""
        Line "Страница открыта. Пройдите тесты, нажмите «Скопировать»," 'DarkGray'
        Line "создайте рядом файл checks_result.json и вставьте туда." 'DarkGray'
        Read-Host "`n  Enter — когда закончите"
    } else {
        Line "checks.html рядом не нашёлся, пропускаю." 'DarkYellow'
    }
}

# ---------------------------------------------------------------- шаг 3
Write-Host ""
Line "[3/3] Открываю заключение." 'White'
Write-Host ""

# Питон здесь больше не нужен: таблица цен лежит рядом готовым файлом,
# а считает по ней сама страница. Python остаётся только инструментом
# разработки — им пересобирают price_table.json после сбора объявлений.
$server = Join-Path $here 'live.ps1'
if (-not (Test-Path $server)) {
    Line "Не нашёл live.ps1 — заключение показать не могу." 'Red'
    Line "Показания железа лежат в scan_result.json" 'DarkGray'
    Read-Host "`n  Enter — выход"; exit 1
}

if (-not (Test-Path (Join-Path $here 'price_table.json'))) {
    Line "Рядом нет price_table.json — оценки цены не будет," 'DarkYellow'
    Line "состояние железа покажу." 'DarkYellow'
    Write-Host ""
}

Line "Цену продавца введёте прямо на странице — она посчитает" 'DarkGray'
Line "справедливую цену сразу, как только наберёте сумму." 'DarkGray'
Write-Host ""
Line "Это окно закрывать нельзя: пока оно открыто, страница живая." 'DarkYellow'
Line "Закончите — нажмите Ctrl+C." 'DarkGray'
Write-Host ""

& powershell -NoProfile -ExecutionPolicy Bypass -File $server
