@echo off
rem ---------------------------------------------------------------
rem  Only ASCII here on purpose.
rem  cmd.exe reads .bat files in the OEM codepage, so Cyrillic text
rem  inside a batch file turns into garbage on some machines and the
rem  script stops parsing. All human-facing text lives in run.ps1,
rem  where UTF-8 works properly. This file only asks for rights and
rem  hands over.
rem ---------------------------------------------------------------

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"
