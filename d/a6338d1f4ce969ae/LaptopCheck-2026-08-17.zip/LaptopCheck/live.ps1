﻿<#
    Живая панель приборов: показания железа в реальном времени.

    Устроено так: PowerShell поднимает крошечный HTTP-сервер на
    localhost, страница в браузере опрашивает его раз в секунду.
    Файл через file:// читать данные не может — браузер это запрещает,
    поэтому нужен именно сервер, пусть и локальный.

    Датчики разной цены. Загрузка процессора и память отдаются за
    миллисекунды, а счётчики надёжности диска — почти две секунды.
    Поэтому дорогие опрашиваются редко и кешируются, иначе панель
    будет заикаться на каждом обновлении.

    Запуск:
        powershell -ExecutionPolicy Bypass -File live.ps1
#>

param(
    [int]$Port = 8731,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$IsAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# ---------------------------------------------------------------- статика

$cpuInfo   = Get-CimInstance Win32_Processor | Select-Object -First 1
$osInfo    = Get-CimInstance Win32_OperatingSystem
$totalRam  = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 1)
$hasNvidia = [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)

# Кеш для дорогих датчиков: значение + время последнего опроса
$slow = @{ diskTemp = $null; diskWear = $null; at = [datetime]::MinValue }

function Get-SlowSensors {
    # Счётчики надёжности накопителя стоят ~2 секунды. Раз в 15 секунд
    # более чем достаточно: температура диска так быстро не меняется.
    if (((Get-Date) - $slow.at).TotalSeconds -lt 15) { return }
    $slow.at = Get-Date
    $d = Get-PhysicalDisk | Where-Object { $_.BusType -notin @('USB','SD','MMC') } |
         Select-Object -First 1
    if ($d) {
        $rc = $d | Get-StorageReliabilityCounter
        if ($rc) {
            if ($rc.Temperature -ne $null) { $slow.diskTemp = [int]$rc.Temperature }
            if ($rc.Wear -ne $null)        { $slow.diskWear = [int]$rc.Wear }
        }
    }
}

function Get-GpuState {
    if (-not $hasNvidia) { return $null }
    $q = 'name,temperature.gpu,utilization.gpu,memory.used,memory.total,clocks.sm,power.draw'
    $line = (& nvidia-smi --query-gpu=$q --format=csv,noheader,nounits 2>$null | Select-Object -First 1)
    if (-not $line) { return $null }
    $p = $line -split '\s*,\s*'
    if ($p.Count -lt 7) { return $null }
    $num = { param($s) $v = 0.0; if ([double]::TryParse($s, [ref]$v)) { $v } else { $null } }
    return [ordered]@{
        name        = $p[0]
        temp_c      = & $num $p[1]
        load_pct    = & $num $p[2]
        mem_used_mb = & $num $p[3]
        mem_total_mb= & $num $p[4]
        clock_mhz   = & $num $p[5]
        power_w     = & $num $p[6]
    }
}

function Get-Sensors {
    Get-SlowSensors

    # Формы Win32_PerfFormattedData_* берём вместо Get-Counter намеренно:
    # у Get-Counter имена счётчиков переведены на язык системы, и на
    # русской Windows английские названия просто не находятся.
    $cpuPerf = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor |
               Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1
    $diskPerf = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk |
                Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1
    $netPerf = Get-CimInstance Win32_PerfFormattedData_Tcpip_NetworkInterface |
               Where-Object { $_.BytesTotalPersec -gt 0 } |
               Sort-Object BytesTotalPersec -Descending | Select-Object -First 1

    $os = Get-CimInstance Win32_OperatingSystem
    $usedRam = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB, 1)

    $cpuNow = Get-CimInstance Win32_Processor | Select-Object -First 1

    $cpuTemp = $null
    $tz = Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature
    if ($tz) {
        $t = ($tz | Measure-Object -Property CurrentTemperature -Maximum).Maximum
        if ($t -gt 0) { $cpuTemp = [math]::Round(($t / 10) - 273.15, 1) }
    }

    $bat = Get-CimInstance Win32_Battery | Select-Object -First 1
    $batRate = $null
    $bs = Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select-Object -First 1
    if ($bs) {
        if ($bs.DischargeRate -gt 0)  { $batRate = -[int]$bs.DischargeRate }
        elseif ($bs.ChargeRate -gt 0) { $batRate = [int]$bs.ChargeRate }
    }

    return [ordered]@{
        # [long], а не [int]: время в миллисекундах с 1970 года — это ~1.8e12,
        # в Int32 такое не влезает, и приведение роняет весь сбор показаний.
        t = [long][math]::Round((Get-Date).ToUniversalTime().Subtract(
                [datetime]'1970-01-01').TotalMilliseconds)
        cpu = [ordered]@{
            load_pct  = $(if ($cpuPerf) { [int]$cpuPerf.PercentProcessorTime } else { $null })
            clock_mhz = $(if ($cpuNow) { [int]$cpuNow.CurrentClockSpeed } else { $null })
            max_mhz   = [int]$cpuInfo.MaxClockSpeed
            temp_c    = $cpuTemp
        }
        gpu = Get-GpuState
        memory = [ordered]@{
            used_gb  = $usedRam
            total_gb = $totalRam
            pct      = $(if ($totalRam -gt 0) { [int](($usedRam / $totalRam) * 100) } else { $null })
        }
        disk = [ordered]@{
            busy_pct   = $(if ($diskPerf) { [math]::Min(100, [int]$diskPerf.PercentDiskTime) } else { $null })
            read_mbs   = $(if ($diskPerf) { [math]::Round($diskPerf.DiskReadBytesPersec / 1MB, 1) } else { $null })
            write_mbs  = $(if ($diskPerf) { [math]::Round($diskPerf.DiskWriteBytesPersec / 1MB, 1) } else { $null })
            temp_c     = $slow.diskTemp
            wear_pct   = $slow.diskWear
        }
        network = [ordered]@{
            mbs = $(if ($netPerf) { [math]::Round($netPerf.BytesTotalPersec / 1MB, 2) } else { 0 })
        }
        battery = [ordered]@{
            present   = ($bat -ne $null)
            charge_pct= $(if ($bat) { [int]$bat.EstimatedChargeRemaining } else { $null })
            rate_mw   = $batRate
            charging  = $(if ($bat) { [int]$bat.BatteryStatus -eq 2 } else { $null })
        }
        admin = $IsAdmin
    }
}

# ---------------------------------------------------------------- сервер

$prefix = "http://localhost:$Port/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
} catch {
    Write-Host ""
    Write-Host "  Не удалось занять порт $Port." -ForegroundColor Red
    Write-Host "  Попробуйте другой:  live.ps1 -Port 8899" -ForegroundColor DarkGray
    Write-Host ""
    exit 1
}

Write-Host ""
Write-Host "  LaptopCheck — живые показания" -ForegroundColor White
Write-Host "  ────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  Панель:  $prefix" -ForegroundColor Cyan
if ($IsAdmin) {
    Write-Host "  Права администратора есть — температуры доступны." -ForegroundColor DarkGreen
} else {
    Write-Host "  Без прав администратора температура CPU не читается." -ForegroundColor DarkYellow
}
if ($hasNvidia) {
    Write-Host "  NVIDIA обнаружена — видеокарта опрашивается полностью." -ForegroundColor DarkGreen
} else {
    Write-Host "  nvidia-smi не найден — данных по видеокарте не будет." -ForegroundColor DarkYellow
}
Write-Host ""
Write-Host "  Закрыть — Ctrl+C в этом окне." -ForegroundColor DarkGray
Write-Host ""

if (-not $NoBrowser) { Start-Process $prefix }

$pagePath = Join-Path $here 'live.html'

try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $req = $ctx.Request
        $res = $ctx.Response
        $res.Headers.Add('Cache-Control', 'no-store')

        try {
            $path = $req.Url.AbsolutePath

            # Страница не может читать файлы с диска напрямую — браузер
            # это запрещает. Поэтому результаты проверки и таблица цен
            # отдаются теми же маршрутами, что и живые датчики.
# Страница одна: живые показания и ручные тесты живут в ней вкладками.
            # Отдельных live.html и checks.html больше нет — две копии одной
            # логики неизбежно разъезжаются.
            $files = @{
                '/'          = @('panel.html', 'text/html; charset=utf-8')
                '/index.html'= @('panel.html', 'text/html; charset=utf-8')
                '/api/scan'  = @('scan_result.json', 'application/json; charset=utf-8')
                '/api/prices'= @('price_table.json', 'application/json; charset=utf-8')
            }

            if ($path -eq '/api') {
                $json = Get-Sensors | ConvertTo-Json -Depth 5 -Compress
                $bytes = [Text.Encoding]::UTF8.GetBytes($json)
                $res.ContentType = 'application/json; charset=utf-8'
                $res.OutputStream.Write($bytes, 0, $bytes.Length)
            }
            elseif ($files.ContainsKey($path)) {
                $name, $type = $files[$path]
                $full = Join-Path $here $name
                if (Test-Path $full) {
                    $bytes = [IO.File]::ReadAllBytes($full)
                    $res.ContentType = $type
                    $res.OutputStream.Write($bytes, 0, $bytes.Length)
                } elseif ($type -like 'application/json*') {
                    # Отсутствующий файл — это пустой результат, а не сбой:
                    # ручную проверку могли просто не проходить.
                    $res.ContentType = $type
                    $empty = [Text.Encoding]::UTF8.GetBytes('null')
                    $res.OutputStream.Write($empty, 0, $empty.Length)
                } else {
                    $res.StatusCode = 404
                    $msg = [Text.Encoding]::UTF8.GetBytes("$name рядом не найден")
                    $res.OutputStream.Write($msg, 0, $msg.Length)
                }
            }
            else {
                $res.StatusCode = 404
            }
        } catch {
            # Глухой catch прячет поломку за пустым ответом с кодом 200 —
            # именно так однажды потерялось переполнение метки времени.
            # Пусть ошибка доезжает до вызывающего и до окна сервера.
            $msg = $_.Exception.Message
            Write-Host "  ! ошибка при сборе показаний: $msg" -ForegroundColor Red
            try {
                $res.StatusCode = 500
                $err = [Text.Encoding]::UTF8.GetBytes(
                    (@{ error = $msg } | ConvertTo-Json -Compress))
                $res.ContentType = 'application/json; charset=utf-8'
                $res.OutputStream.Write($err, 0, $err.Length)
            } catch { }
        }
        $res.Close()
    }
} finally {
    $listener.Stop()
    $listener.Close()
    Write-Host ""
    Write-Host "  Панель остановлена." -ForegroundColor DarkGray
    Write-Host ""
}
